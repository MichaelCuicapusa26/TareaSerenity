package com.vichamalab.serenitybdd.restinteractions;

import org.junit.jupiter.api.extension.ExtendWith;

import com.vichamalab.serenitybdd.dto.ProductRequestDTO;
import com.vichamalab.serenitybdd.dto.ProductResponse;
import io.cucumber.java.Before;
import net.serenitybdd.core.Serenity;
//import io.cucumber.java.Before;
import net.serenitybdd.junit5.SerenityJUnit5Extension;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.serenitybdd.screenplay.rest.interactions.Delete;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.serenitybdd.screenplay.rest.interactions.Put;
import net.serenitybdd.screenplay.rest.interactions.Patch;
import net.thucydides.model.util.EnvironmentVariables;
import static net.serenitybdd.screenplay.rest.questions.ResponseConsequence.seeThatResponse;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItems;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("SerenityRestInteractions")
@ExtendWith(SerenityJUnit5Extension.class)
public class ScreenplayRestInteractionsTestSuite {
	private EnvironmentVariables environmentVariables;

	@Test
	@Tag("rest1")
	@DisplayName("Listar productos")
	public void listar_productos() {
		String baseUrl = environmentVariables.optionalProperty("restapi.baseurl")
				.orElse("");

		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at(baseUrl));

		authorizeUser.attemptsTo(
				Get.resource("api/v1/product/"));
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 200 y el estado es verdadero",
						response -> response.statusCode(200)
								.body("status", equalTo(true))));
	}

	@Test
	@Tag("rest")
	@DisplayName("crear producto")
	public String crear_producto() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("Iphone 13 Premium")
				.description("Telefono alta gama")
				.price(1400)
				.build();

		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));

		authorizeUser.attemptsTo(
				Post.to("api/v1/product/")
						.with(request -> request.header("Content-Type", "application/json").and().header("Authorization","Bearer aGFzaGRzZnNkZnNkZnNkZnNk")
								.body(productRequest)));
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 201 y el estado es verdadero",
						response -> response.statusCode(201)
								.body("status", equalTo(true))));

		String sku_response = SerenityRest.lastResponse().path("sku");
		return sku_response;
	}

	// TAREA HAPPY PATH Y SAD PATH DELETE AND GET
	// HAPPY PATH

	@Test
	@Tag("rest1")
	@DisplayName("obtener producto")
	public void obtener_producto() {
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));

		authorizeUser.attemptsTo(
				Get.resource("api/v1/product/{sku}/").with(request -> request.pathParam("sku", this.crear_producto())));
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 201 y el estado es verdadero",
						response -> response.statusCode(201)
								.body("status", equalTo(true))));
	}

	@Test
	@Tag("rest1")
	@DisplayName("eliminar producto")
	public void eliminar_producto() {
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));

		authorizeUser.attemptsTo(
				Delete.from("api/v1/product/{sku}/").with(request -> request.pathParam("sku", this.crear_producto())));
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 201 y el estado es verdadero",
						response -> response.statusCode(201)
								.body("status", equalTo(true))));
	}
	

	// SAD PATH
	@Test
	@Tag("rest1")
	@DisplayName("obtener producto sad path")
	public void obtener_producto_sad_path() {
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));

		String skuTemporal = "6ab5af78-daea-4d48-aede-04f945084a9b";
		authorizeUser.attemptsTo(
				Get.resource("api/v1/product/" + skuTemporal));
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 404 y el estado es 404",
						response -> response.statusCode(404)
								.body("status", equalTo(404))));
	}

	@Test
	@Tag("rest1")
	@DisplayName("eliminar producto sad path")
	public void eliminar_producto_sad_path() {
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));

		String skuTemporal = "28666904-32af-4ac6-a2a6-2c9cc6662721";
		authorizeUser.attemptsTo(
				Delete.from("api/v1/product/{sku}").with(request -> request.pathParam("sku", skuTemporal)));
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 404 y el estado es 404",
						response -> response.statusCode(404)
								.body("status", equalTo(404))));
	}
	
	//TAREA SAD PATH
	
	//CREAR PRODUCTO
	
	@Test
	@Tag("rest")
	@DisplayName("Crear Producto - Token invalido - SAD PATH")
	public void Crear_Producto_sad_path_token_invalido() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("Galaxy S24")
				.description("Celular alta gama de Samsung")
				.price(4000)
				.build();
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		
		authorizeUser.attemptsTo(
				Post.to("api/v1/product/")
				.with(request -> request.header("Content-type","application/json").and().header("Authorization","Bearer aGFzaGRzZnNkZnNkZnNkZnNfsdfsdf")
						.body(productRequest)));
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: Invalid permissions",
						response -> {
							response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("Invalid permissions"));
						}));
						
	}
	
	
	@Test
	@Tag("rest")
	@DisplayName("Crear Producto - Falta Nombre - SAD PATH")
	public void Crear_Producto_sad_path_falta_nombre() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("")
				.description("Celular alta gama de Samsung")
				.price(4000)
				.build();
		
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		
		authorizeUser.attemptsTo(
				Post.to("api/v1/product/")
				.with(request -> request.header("Content-type","application/json").and().header("Authorization","Bearer aGFzaGRzZnNkZnNkZnNkZnNk")
						.body(productRequest)));
		
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: El nombre del producto no fue proporcionado",
						response -> {
							response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("El nombre del producto no fue proporcionado"));
						}));
	}
	
	@Test
	@Tag("rest")
	@DisplayName("Crear Producto - Falta Descripcion - SAD PATH")
	public void Crear_Producto_sad_path_falta_descripcion() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("Galaxy S24")
				.description("")
				.price(4000)
				.build();
		
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		
		authorizeUser.attemptsTo(
				Post.to("api/v1/product/")
				.with(request -> request.header("Content-type","application/json").and().header("Authorization","Bearer aGFzaGRzZnNkZnNkZnNkZnNk")
						.body(productRequest)));
		
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: La descripción del producto no fue proporcionada",
						response -> {
							response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("La descripción del producto no fue proporcionada"));
						}));
	}
	
	@Test
	@Tag("rest")
	@DisplayName("Crear Producto - Falta Precio - SAD PATH")
	public void Crear_Producto_sad_path_falta_precio() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("Galaxy S24")
				.description("Celular alta gama de Samsung")
				.price(0)
				.build();
		
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		
		authorizeUser.attemptsTo(
				Post.to("api/v1/product/")
				.with(request -> request.header("Content-type","application/json").and().header("Authorization","Bearer aGFzaGRzZnNkZnNkZnNkZnNk")
						.body(productRequest)));
		
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: El precio del producto no fue proporcionado",
						response -> {
							response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("El precio del producto no fue proporcionado"));
						}));
	}
	
	//ACTUALIZAR PRODUCTO
	
	@Test
	@Tag("rest")
	@DisplayName("Actualizar Producto - Producto no encontrado - SAD PATH")
	public void Actualizar_Producto_sad_path_producto_no_encontrado() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("Galaxy S24")
				.description("Celular alta gama de Samsung")
				.price(4000)
				.build();
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		
		authorizeUser.attemptsTo(
				Put.to("api/v1/product/{sku}/")
				.with(request -> request.header("Content-type","application/json")
						.pathParam("sku","a")
						.body(productRequest)));
		
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: El producto no fue encontrado",
						response -> {
							response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("El producto no fue encontrado"));
						}));	
	}
	
	
	
	@Test
	@Tag("rest")
	@DisplayName("Actualizar Producto - Falta Nombre - SAD PATH")
	public void Actualizar_Producto_sad_path_falta_nombre() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("")
				.description("Celular alta gama de Samsung")
				.price(4000)
				.build();
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		String sku = this.crear_producto();
		
		authorizeUser.attemptsTo(
				Put.to("api/v1/product/{sku}/")
				.with(request -> request.header("Content-type","application/json")
						.pathParam("sku",sku)
						.body(productRequest)));
		
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: El nombre del producto no fue proporcionado",
						response -> {
							response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("El nombre del producto no fue proporcionado"));
						}));
	}
	
	
	@Test
	@Tag("rest")
	@DisplayName("Actualizar Producto - Falta Descripcion - SAD PATH")
	public void Actualizar_Producto_sad_path_falta_descripcion() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("Galaxy S24")
				.description("")
				.price(4000)
				.build();
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		String sku = this.crear_producto();
		
		authorizeUser.attemptsTo(
				Put.to("api/v1/product/{sku}/")
				.with(request -> request.header("Content-type","application/json")
						.pathParam("sku",sku)
						.body(productRequest)));
		
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: La descripción del producto no fue proporcionada",
						response -> {
							response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("La descripción del producto no fue proporcionada"));
						}));
	}
	
	
	@Test
	@Tag("rest")
	@DisplayName("Actualizar Producto - Falta Precio - SAD PATH")
	public void Actualizar_Producto_sad_path_falta_precio() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("Galaxy S24")
				.description("Celular alta gama de Samsung")
				.price(0)
				.build();
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		
		 String sku = this.crear_producto();
		
		authorizeUser.attemptsTo(
				Put.to("api/v1/product/{sku}/")
				.with(request -> request.header("Content-type","application/json")
						.pathParam("sku",sku)
						.body(productRequest)));
		
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: El precio del producto no fue proporcionado",
						response -> {
						response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("El precio del producto no fue proporcionado"));
						}));
	}
	
	//ACTUALIZAR PRECIO PRODUCTO EXISTENTE
	
	@Test
	@Tag("rest")
	@DisplayName("Actualizar Precio Producto - Producto no Encontrado - SAD PATH")
	public void Actualizar_Precio_Producto_sad_path_Producto_no_encontrado() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("Galaxy S24")
				.description("Celular alta gama de Samsung")
				.price(5000)
				.build();
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		
		authorizeUser.attemptsTo(
				Patch.to("api/v1/product/{sku}/")
				.with(request -> request.header("Content-type","application/json")
						.pathParam("sku","a")
						.body(productRequest)));
		
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: El producto no fue encontrado",
						response -> {
						response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("El producto no fue encontrado"));
						}));
	}
	
	@Test
	@Tag("rest")
	@DisplayName("Actualizar Precio Producto - Producto igual o menor a 0 - SAD PATH")
	public void Actualizar_Precio_Producto_sad_path_Producto_precio_0() {
		ProductRequestDTO productRequest = ProductRequestDTO.builder()
				.name("Galaxy S24")
				.description("Celular alta gama de Samsung")
				.price(0)
				.build();
		
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		
		 String sku = this.crear_producto();
		
		authorizeUser.attemptsTo(
				Patch.to("api/v1/product/{sku}/")
				.with(request -> request.header("Content-type","application/json")
						.pathParam("sku",sku)
						.body(productRequest)));
		
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 400, el estado es falso y la respuesta es: El precio del producto debe ser mayor a 0",
						response -> {
						response.statusCode(400);
						response.body("status",equalTo(false));
						response.body("message",equalTo("El precio del producto debe ser mayor a 0"));
						}));
	}	
	
	
	//LISTAR PRODUCTO
	
	@Test
	@Tag("rest")
	@DisplayName("Listar producto por SKU - Producto no encontrado - SAD PATH")
	public void listar_sku_producto() {
		String baseUrl = environmentVariables.optionalProperty("restapi.baseurl")
				.orElse("");

		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));

		authorizeUser.attemptsTo(
				Get.resource("api/v1/product/{sku}/")
				.with(request -> request.header("Content-type","application/json")
						.pathParam("sku","A")));
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 200, el estado es verdadero y la respuesta es: El producto no fue encontrado",
						response -> {
								response.statusCode(200);
								response.body("status", equalTo(false));
								response.body("message",equalTo("El producto no fue encontrado"));
						
						}));
	}
	
	
	@Test
	@Tag("rest")
	@DisplayName("Listar todos los productos- Productos no encontrados - SAD PATH")
	public void listar_productos_sad_path() {
		String baseUrl = environmentVariables.optionalProperty("restapi.baseurl")
				.orElse("");

		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		
		authorizeUser.attemptsTo(
				Get.resource("api/v1/product/?name={name}")
				.with(request -> request.header("Content-type","application/json")
						.pathParam("name","zzz")));
		
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 200, el estado es verdadero y la respuesta es: Se encontró 0 producto(s)",
						response -> {
								response.statusCode(200);
								response.body("status", equalTo(true));
								response.body("message",equalTo("Se encontró 0 producto(s)"));	
						}));
	}
	
	//ELIMINAR PRODUCTO
	
	@Test
	@Tag("rest")
	@DisplayName("Eliminar producto - Producto no encontrado - SAD PATH")
	public void eliminar_producto_sad_path_producto_no_encontrado() {
		Actor authorizeUser = Actor.named("Usuario Autorizado")
				.whoCan(CallAnApi.at("http://localhost:8081/"));
		


		authorizeUser.attemptsTo(
				Delete.from("api/v1/product/{sku}/").
				with(request -> request.pathParam("sku", "aaa")));
		authorizeUser.should(
				seeThatResponse("El codigo de respuesta es 404, el estado es falso y la respuesta es: El producto no fue encontrado",
						response ->{
								response.statusCode(404);
								response.body("status",equalTo(false));
								response.body("message", equalTo("El producto no fue encontrado"));
						}));
	}
	
	

	
	
	

	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
